			<div class="card border-light mb-3" style="max-width: 18rem;">
			  <div class="card-header" class="text-center"><i class="fas fa-filter"></i> Filtros</div>
				  <div class="card-body">
				  	<form action="<?php echo e(route('filtrar.post')); ?>" method="get">
				  		<?php echo csrf_field(); ?>
				  		<label for="exampleFormControlSelect1">Categorías</label>
						<select class="form-control" id="exampleFormControlSelect1" name="category">

						<?php if(isset($category)): ?>
						  <option value="<?php echo e($category); ?>"><?php echo e($category); ?></option>
						  <option value="">Seleccione una categoría</option>
					      <option value="Adopción">Adopción</option>
					      <option value="Encuentro">Encuentro</option>
					      <option value="Estado crítico">Estado crítico</option>
					      <option value="Pérdida">Pérdida</option>
						<?php else: ?>
						  <option disabled selected>Seleccione una categoría</option>
					      <option value="Adopción">Adopción</option>
					      <option value="Encuentro">Encuentro</option>
					      <option value="Estado crítico">Estado crítico</option>
					      <option value="Pérdida">Pérdida</option>
						<?php endif; ?>
						</select>

						<br>

						<label for="exampleFormControlSelect1">Tipo de animal</label>
					    <select class="form-control" name="animal_type" id="exampleFormControlSelect1">

					    <?php if(isset($animal_type)): ?>
					      <option value="<?php echo e($animal_type); ?>"><?php echo e($animal_type); ?></option>
					      <option value="">Seleccione el tipo de animal</option>
					      <option value="Canino">Canino</option>
					      <option value="Felino">Felino</option>
					      <option value="Ave">Ave</option>
					      <option value="Roedor">Roedor</option>
					      <option value="Equino">Equino</option>
					      <option value="Otro">Otro</option>
					    <?php else: ?>
					      <option disabled selected>Seleccione el tipo de animal</option>
					      <option value="Canino">Canino</option>
					      <option value="Felino">Felino</option>
					      <option value="Ave">Ave</option>
					      <option value="Roedor">Roedor</option>
					      <option value="Equino">Equino</option>
					      <option value="Otro">Otro</option>
					    <?php endif; ?>
					    </select>

				  		<br>

						<label for="exampleFormControlSelect1">Zona</label>
					    <select class="form-control" name="zone" id="exampleFormControlSelect1">

					    <?php if(isset($zone)): ?>
					    	<?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lugar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					    		<?php if($lugar->id == $zone): ?>
					    		<option value="<?php echo e($lugar->id); ?>"><?php echo e($lugar->name); ?></option>
					    		<?php endif; ?>
					    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					    	<option value="">Seleccione una zona</option>
					    	<optgroup label="CABA">
						    	<?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						    		<?php if($zone->id>0 && $zone->id<49): ?>
						    		<option value="<?php echo e($zone->id); ?>"><?php echo e($zone->name); ?></option>
						    		<?php endif; ?>
						    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					    	</optgroup>
					    	<optgroup label="Buenos Aires Provincia">
						    	<?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						    		<?php if($zone->id>50): ?>
										<option  value="<?php echo e($zone->id); ?>"><?php echo e($zone->name); ?></option>
						    		<?php endif; ?>
						    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					    	</optgroup>
					    <?php else: ?>
					    	<option disabled selected>Seleccione una zona</option>
					    	<optgroup label="CABA">
						    	<?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						    		<?php if($zone->id>0 && $zone->id<49): ?>
						    		<option value="<?php echo e($zone->id); ?>"><?php echo e($zone->name); ?></option>
						    		<?php endif; ?>
						    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					    	</optgroup>
					    	<optgroup label="Buenos Aires Provincia">
						    	<?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						    		<?php if($zone->id>50): ?>
										<option  value="<?php echo e($zone->id); ?>"><?php echo e($zone->name); ?></option>
						    		<?php endif; ?>
						    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					    	</optgroup>
					    <?php endif; ?>
					    </select>

					    <br>

					    <button type="submit" class="btn btn-info">Ir</button>
				  	</form>

				  </div>
			</div>
<?php /**PATH C:\laragon\www\reddema\resources\views/posts/includes/filtros.blade.php ENDPATH**/ ?>