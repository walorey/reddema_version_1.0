			<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="card border-info mb-3">
			  <div class="card-header">
			    <span><i class="fas fa-list-ul"></i> <a href="<?php echo e(route('filtrar.categoria', $post->category)); ?>"><?php echo e($post->category); ?></a></span>
			    <span>|</span>
			    <span><i class="fas fa-paw"></i> <a href="<?php echo e(route('filtrar.tipoAnimal' ,$post->animal_type)); ?>"><?php echo e($post->animal_type); ?></a>
			    </span>
			    <span>|</span>
			    <span>
			    	<i class="fas fa-map-marker-alt"></i>

			      	<a href="<?php echo e(route('filtrar.zona',  [$post->zone->name,$post->zone->id])); ?>">
			      		<?php echo e($post->zone->name); ?>

			      	</a>
				</span>
				<span>|</span>
				<span><?php echo e($post->created_at); ?></span>
				<span class="float-right"><?php echo e($post->user->name); ?> <?php echo e($post->user->lastname); ?></span>




			  </div>
			  <div class="card-body">
			    <h5 class="card-title"><?php echo e($post->title); ?></h5>
			    <p class="card-text"><?php echo e($post->description); ?></p>
			    <div class="container">
			    	<div class="row">
				    <?php $__currentLoopData = $post->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

						<!-- Button trigger modal -->
						<a href="#"  data-toggle="modal" data-target="#image-<?php echo e($image->id); ?>">
						  <img src="<?php echo e(Storage::url($image->ruta)); ?>" class="img-thumbnail" style="width: 190px; height: 190px;">
						</a>

						<!-- Modal -->
						<div class="modal fade" id="image-<?php echo e($image->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
						  <div class="modal-dialog" role="document">
						    <div class="modal-content">
						      <div class="modal-header">
						        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
						          <span aria-hidden="true">&times;</span>
						        </button>
						      </div>
						      <div class="modal-body">
						        <img src="<?php echo e(Storage::url($image->ruta)); ?>" class="img-thumbnail">
						      </div>
						    </div>
						  </div>
						</div>

				    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				    </div>
			    </div>

			  </div>
			    <div class="card-footer text-muted">
			    	<i class="fas fa-comment"></i>
			    	<a href="<?php echo e(route('posts.show', $post->id)); ?>">Comentar</a>
				 </div>
			</div>
			<br>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php echo $posts->appends(Request::only(['category', 'animal_type', 'zone']))->render(); ?><?php /**PATH C:\laragon\www\reddema\resources\views/posts/includes/publicaciones.blade.php ENDPATH**/ ?>