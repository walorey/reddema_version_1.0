	<?php if($errors->any()): ?>
    <div class="alert alert-danger fade show">
    	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
		    <span aria-hidden="true">&times;</span>
		</button>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
	<?php endif; ?>
	<?php if(session('mensaje')): ?>
    <div class="alert alert-success fade show">
    	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
		    <span aria-hidden="true">&times;</span>
		</button>
        <ul>
			<?php echo e(session('mensaje')); ?>

        </ul>
    </div>
	<?php endif; ?>
<?php /**PATH C:\laragon\www\reddema\resources\views/posts/includes/alertas.blade.php ENDPATH**/ ?>