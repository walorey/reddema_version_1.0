<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12"></div>
		<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
			<div class="card">
			  <div class="card-header">
			  <span style="font-size: 19px;"><?php echo e($post->title); ?></span>
			  <span class="float-right"><?php echo e($post->user->name); ?> <?php echo e($post->user->lastname); ?></span>
			  </div>
			  <div class="card-body">
			    <p class="card-text"><?php echo e($post->description); ?></p>
			    <div class="container">
					    	<div class="row">
						    <?php $__currentLoopData = $post->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

								<!-- Button trigger modal -->
								<a href="#"  data-toggle="modal" data-target="#image-<?php echo e($image->id); ?>">
								  <img src="<?php echo e(Storage::url($image->ruta)); ?>" class="img-thumbnail" style="width: 190px; height: 190px;">
								</a>

								<!-- Modal -->
								<div class="modal fade" id="image-<?php echo e($image->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
								  <div class="modal-dialog" role="document">
								    <div class="modal-content">
								      <div class="modal-header">
								        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
								          <span aria-hidden="true">&times;</span>
								        </button>
								      </div>
								      <div class="modal-body">
								        <img src="<?php echo e(Storage::url($image->ruta)); ?>" class="img-thumbnail">
								      </div>
								    </div>
								  </div>
								</div>

						    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						    </div>
					    </div>
			  </div>
			  <div class="card-footer">
			  	<span><i class="fas fa-list"></i> <a href="<?php echo e(route('filtrar.categoria', $post->category)); ?>"><?php echo e($post->category); ?></a></span>

			  	<span>|</span>

			  	<span><i class="fas fa-paw"></i> <a href="<?php echo e(route('filtrar.tipoAnimal', $post->animal_type)); ?>"><?php echo e($post->animal_type); ?></a></span>

			  	<span>|</span>

			  	<span><i class="fas fa-map-marker-alt"></i><a href="<?php echo e(route('filtrar.zona', [$post->zone->name,$post->zone->id])); ?>"> <?php echo e($post->zone->name); ?></a></span>

			  	<span class="float-right"><?php echo e($post->created_at); ?></span>

			  </div>
			</div>

			<br>

		

			<h3>Comentarios</h3>

			<?php if($post->comments->count() == 0): ?>

				<p>¡Sé el primero en comentar!</p>
			<?php else: ?>
					<?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comentario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="card mb-3">
					  <div class="row no-gutters">
					    <div class="col-md-3">
					      <img src="<?php echo e(asset('img/avatar-comentario.jpg')); ?>" alt="..." style="width: 150px; height: 150px;">
					    </div>
					    <div class="col-md-9">
					      <div class="card-body">
					        <h5 class="card-title"><?php echo e($comentario->user->name); ?> <?php echo e($comentario->user->lastname); ?></h5>
					        <p class="card-text"><?php echo e($comentario->body); ?></p>
					        <p class="card-text"><small class="text-muted"><?php echo e($comentario->created_at); ?></small></p>
					      </div>
					    </div>
					  </div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
			<?php if(session('mensaje')): ?>
			<br>
			<div class="alert alert-success alert-dismissible fade show" role="alert">
			  <strong><?php echo e(session('mensaje')); ?></strong>
			  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
			    <span aria-hidden="true">&times;</span>
			  </button>
			</div>
			<?php endif; ?>

			<br>

			<div class="card border-info mb-3">
			  <div class="card-header">Comentar</div>
			  <div class="card-body text-info">
			  	<form action="<?php echo e(route('post.comentar', $post->id)); ?>" method="post" >
			  		<?php echo csrf_field(); ?>
			  	  <div class="form-group">
				    <textarea class="form-control" id="exampleFormControlTextarea1" name="body" rows="3"></textarea>
				  </div>
				  <button type="submit" class="btn btn-outline-primary">Enviar</button>
			  	</form>
			  </div>
			</div>

		</div>
		<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12"></div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\reddema\resources\views/posts/publicacion.blade.php ENDPATH**/ ?>