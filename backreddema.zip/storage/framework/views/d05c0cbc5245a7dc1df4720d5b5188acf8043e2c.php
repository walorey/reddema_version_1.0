<?php $__env->startSection('content'); ?>
<div class="container">
	<?php echo $__env->make('posts.includes.alertas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="row">
		<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
			<button type="button" class="btn btn-outline-success btn-lg btn-block" data-toggle="modal" data-target="#modalPublicar">Publicar</button>
			<br>
			<?php echo $__env->make('posts.includes.filtros', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
		<div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">



			<?php if($posts->count() == 0): ?>

			<h2 class="text-center">No hay publicaciones.</h2>
			<h3 class="text-center">Prueba cambiando los filtros.</h3>

			<?php endif; ?>

			<?php echo $__env->make('posts.includes.publicaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
		<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
			<?php echo $__env->make('posts.includes.zonas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
	</div>
</div>

<?php echo $__env->make('posts.includes.crearPublicacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\reddema\resources\views/posts/index.blade.php ENDPATH**/ ?>