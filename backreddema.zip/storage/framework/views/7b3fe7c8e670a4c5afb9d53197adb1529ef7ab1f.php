<?php $__env->startSection('content'); ?>

	<div class="container">
		<h1>Notificaciones</h1>
		<div class="row">
			<div class="col-md-6">
				<h2>No Leídas</h2>
				<ul class="list-group">
					<?php $__currentLoopData = $unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unreadNotification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li class="list-group-item">
							<a href="<?php echo e($unreadNotification->data['link']); ?>">
								<?php echo e($unreadNotification->data['subject']); ?>

							</a>
							<form class="float-right" method="post" action="<?php echo e(route('notifications.read', $unreadNotification->id)); ?>">
								    <?php echo e(csrf_field()); ?>

    								<?php echo e(method_field('PATCH')); ?>

								<button class="btn btn-secondary"><i class="far fa-envelope-open"></i></button>
							</form>
						</li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<div class="col-md-6">
				<h2>Leídas</h2>
				<ul class="list-group">
					<?php $__currentLoopData = $readNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $readNotification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li class="list-group-item">
							<a href="<?php echo e($readNotification->data['link']); ?>">
								<?php echo e($readNotification->data['subject']); ?>

							</a>
							<form class="float-right" method="post" action="<?php echo e(route('notifications.destroy', $readNotification->id)); ?>">
								    <?php echo e(csrf_field()); ?>

    								<?php echo e(method_field('DELETE')); ?>

								<button class="btn btn-danger">x</button>
							</form>
						</li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\reddema\resources\views/notifications/index.blade.php ENDPATH**/ ?>