<!-- Modal -->
<div class="modal fade" id="modalPublicar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-center" id="exampleModalLabel">Publicar algo en Reddema</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="container">

			<form action="<?php echo e(route('posts.store')); ?>" method="post" enctype="multipart/form-data" >
			  <?php echo csrf_field(); ?>
			  <div class="form-group">
			  	<label>Título</label>
			  	<input class="form-control" name="title" type="text" placeholder="Perro negro perdido, Encontre un gato..." value="<?php echo e(old('title')); ?>">
			  </div>
			  <div class="form-group">
			    <label for="exampleFormControlSelect1">Categoria</label>
			    <select class="form-control" id="exampleFormControlSelect1" name="category">
			      <option disabled selected>Seleccione una categoría</option>
			      <option value="Adopción">Adopción</option>
			      <option value="Encuentro">Encuentro</option>
			      <option value="Estado crítico">Estado crítico</option>
			      <option value="Pérdida">Pérdida</option>
			    </select>
			  </div>
			   <div class="form-group">
			    <label for="exampleFormControlSelect1">Tipo de animal</label>
			    <select class="form-control" name="animal_type" id="exampleFormControlSelect1">
			      <option disabled selected>Seleccione el tipo de animal</option>
			      <option value="Canino">Canino</option>
			      <option value="Felino">Felino</option>
			      <option value="Ave">Ave</option>
			      <option value="Roedor">Roedor</option>
			      <option value="Equino">Equino</option>
			      <option value="Otro">Otro</option>
			    </select>
			  </div>
			  <div class="form-group">
			    <label for="exampleFormControlSelect1">Zona</label>
			    <select class="form-control" name="zone" id="exampleFormControlSelect1">
			    	<option disabled selected>Seleccione una zona</option>
			    	<optgroup label="CABA">
				    	<?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    		<?php if($zone->id>0 && $zone->id<49): ?>
				    		<option value="<?php echo e($zone->id); ?>"><?php echo e($zone->name); ?></option>
				    		<?php endif; ?>
				    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			    	</optgroup>
			    	<optgroup label="Buenos Aires Provincia">
				    	<?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    		<?php if($zone->id>50): ?>
								<option  value="<?php echo e($zone->id); ?>"><?php echo e($zone->name); ?></option>
				    		<?php endif; ?>
				    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			    	</optgroup>
			    </select>
			  </div>
			  <div class="form-group">
			    <label for="exampleFormControlFile1">Imagenes</label>
			    <input type="file" name="images[]" multiple class="form-control-file" id="exampleFormControlFile1">
			  </div>
			<div class="form-group">
			    <label for="exampleFormControlTextarea1">Detalles</label>
			    <textarea name="description" placeholder="Deja detalles, datos de contacto, telefonos, emails o redes sociales" class="form-control"  rows="3"value="<?php echo e(old('description')); ?>"></textarea>
			  </div>
			  <button type="submit" class="btn btn-primary">Publicar</button>
			</form>
		</div>
      </div>

    </div>
  </div>
</div><?php /**PATH C:\laragon\www\reddema\resources\views/posts/includes/crearPublicacion.blade.php ENDPATH**/ ?>